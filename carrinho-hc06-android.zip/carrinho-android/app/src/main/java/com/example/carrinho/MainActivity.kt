package com.example.carrinho

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.OutputStream
import java.util.UUID

private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

private val Fundo = Color(0xFF111827)
private val Azul = Color(0xFF2563EB)
private val Vermelho = Color(0xFFDC2626)
private val Verde = Color(0xFF16A34A)

class Carrinho(private val scope: CoroutineScope) {
    var conectado by mutableStateOf(false)
        private set
    var conectando by mutableStateOf(false)
        private set
    var erro by mutableStateOf<String?>(null)
        private set

    // Mudar o comando envia na hora; o ciclo abaixo repete a cada 100 ms
    @Volatile
    var comando: Char = 'S'
        set(v) {
            if (field != v) {
                field = v
                scope.launch(Dispatchers.IO) { enviar(v) }
            }
        }

    private var socket: BluetoothSocket? = null
    private var saida: OutputStream? = null
    private var ciclo: Job? = null

    @SuppressLint("MissingPermission")
    fun conectar(device: BluetoothDevice) {
        if (conectando || conectado) return
        conectando = true
        erro = null
        scope.launch(Dispatchers.IO) {
            try {
                val s = device.createRfcommSocketToServiceRecord(SPP)
                s.connect()
                socket = s
                saida = s.outputStream
                comando = 'S'
                conectado = true
                enviar('S')
                ciclo = launch {
                    while (isActive) {
                        enviar(comando)
                        delay(100)
                    }
                }
            } catch (e: Exception) {
                fechar()
                erro = e.message ?: "Falha ao conectar"
            } finally {
                conectando = false
            }
        }
    }

    fun desconectar() {
        scope.launch(Dispatchers.IO) { fechar() }
    }

    @Synchronized
    private fun enviar(c: Char) {
        try {
            saida?.write(c.code)
            saida?.flush()
        } catch (e: Exception) {
            fechar()
        }
    }

    private fun fechar() {
        ciclo?.cancel()
        ciclo = null
        try {
            saida?.write('S'.code)
            saida?.flush()
        } catch (_: Exception) {
        }
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        socket = null
        saida = null
        comando = 'S'
        conectado = false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { Tela() }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun Tela() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val carrinho = remember { Carrinho(scope) }
    var dispositivos by remember { mutableStateOf(listOf<BluetoothDevice>()) }
    var escolhido by remember { mutableStateOf<BluetoothDevice?>(null) }
    var menu by remember { mutableStateOf(false) }

    fun temPermissao() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) ==
        PackageManager.PERMISSION_GRANTED

    fun atualizar() {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
        dispositivos = if (adapter != null && temPermissao()) adapter.bondedDevices.toList() else emptyList()
        if (dispositivos.none { it.address == escolhido?.address }) {
            escolhido = dispositivos.firstOrNull()
        }
    }

    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { atualizar() }

    LaunchedEffect(Unit) {
        if (temPermissao()) atualizar() else pedir.launch(Manifest.permission.BLUETOOTH_CONNECT)
    }
    DisposableEffect(Unit) { onDispose { carrinho.desconectar() } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Fundo)
            .statusBarsPadding()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("CARRINHO HC-06", color = Color(0xFF38BDF8), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box {
                OutlinedButton(onClick = { menu = true }, enabled = !carrinho.conectado) {
                    Text(escolhido?.name ?: "Sem dispositivo pareado")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    dispositivos.forEach { d ->
                        DropdownMenuItem(
                            text = { Text("${d.name ?: "?"}  (${d.address})") },
                            onClick = { escolhido = d; menu = false }
                        )
                    }
                }
            }
            Spacer(Modifier.width(8.dp))
            Button(onClick = { atualizar() }, enabled = !carrinho.conectado) { Text("Atualizar") }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (carrinho.conectado) carrinho.desconectar()
                else escolhido?.let { carrinho.conectar(it) }
            },
            enabled = !carrinho.conectando && (carrinho.conectado || escolhido != null),
            colors = ButtonDefaults.buttonColors(containerColor = if (carrinho.conectado) Vermelho else Verde),
            modifier = Modifier.fillMaxWidth(0.7f)
        ) {
            Text(
                when {
                    carrinho.conectando -> "CONECTANDO..."
                    carrinho.conectado -> "DESCONECTAR"
                    else -> "CONECTAR"
                }
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            carrinho.erro ?: if (carrinho.conectado) "Conectado" else "Desconectado",
            color = if (carrinho.conectado) Color(0xFF4ADE80) else Color(0xFFF87171)
        )

        Spacer(Modifier.weight(1f))

        Row { Spacer(Modifier.size(104.dp)); Botao("▲", 'F', carrinho, Azul); Spacer(Modifier.size(104.dp)) }
        Row {
            Botao("◀", 'L', carrinho, Azul)
            Botao("PARAR", 'S', carrinho, Vermelho)
            Botao("▶", 'R', carrinho, Azul)
        }
        Row { Spacer(Modifier.size(104.dp)); Botao("▼", 'B', carrinho, Azul); Spacer(Modifier.size(104.dp)) }

        Spacer(Modifier.weight(1f))
    }
}

@Composable
fun Botao(texto: String, cmd: Char, carrinho: Carrinho, cor: Color) {
    var pressionado by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .padding(4.dp)
            .size(96.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (pressionado) cor.copy(alpha = 0.6f) else cor)
            .pointerInput(cmd) {
                awaitEachGesture {
                    awaitFirstDown()
                    pressionado = true
                    carrinho.comando = cmd
                    waitForUpOrCancellation()
                    pressionado = false
                    // Só para se este botão ainda for o comando ativo
                    if (cmd != 'S' && carrinho.comando == cmd) carrinho.comando = 'S'
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(texto, color = Color.White, fontSize = if (cmd == 'S') 16.sp else 26.sp, fontWeight = FontWeight.Bold)
    }
}
